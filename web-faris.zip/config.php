<?php

$databaseHost = 'localhost';
$databaseName = 'topup_diamond';
$databaseUsername = 'root';
$databasePassword = '';
$databasePort = '3306';

$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName, $databasePort); 

?>